package mx.FBD;

public class Efectivo extends Pago {
    public Efectivo(){
        super();
    }

    public Efectivo(int idPago){
        super(idPago);
    }
}
