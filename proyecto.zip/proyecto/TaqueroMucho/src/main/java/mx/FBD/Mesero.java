package mx.FBD;

public class Mesero extends Empleado {
    public Mesero(String nombre, String paterno, String materno, String curp, String calle, int numero, String colonia, String alcaldia, String cp, String nacimiento, String tipoSangre){
        super(nombre, paterno, materno, curp, calle, numero, colonia, alcaldia, cp, nacimiento, tipoSangre);
    }
}
