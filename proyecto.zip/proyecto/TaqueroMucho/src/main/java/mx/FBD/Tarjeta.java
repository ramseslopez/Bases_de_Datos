package mx.FBD;

public class Tarjeta extends Pago {

    public Tarjeta(){
        super();
    }

    public Tarjeta(int idPago){
        super(idPago);
    }
}
