package mx.FBD;

public class ClienteNormal extends Cliente {
    public ClienteNormal(){
        super();
    }

    public ClienteNormal(String nombre, String paterno, String materno, int idCliente){
        super(nombre, paterno, materno, idCliente);
    }
}
