USE Northwind;

DROP INDEX condigoPostalDestinatario ON Pedidos;
ALTER TABLE Pedidos DROP COLUMN condigoPostalDestinatario;
ALTER TABLE Pedidos ADD codigoPostalDestinatario nvarchar (10) NULL;
CREATE INDEX "codigoPostalDestinatario" ON "dbo"."Pedidos"("codigoPostalDestinatario")

USE Northwind;

CREATE TABLE [dbo].[Region]
 ( [idRegion] [int] NOT NULL ,
 [descripcionRegion] [nchar] (50) NOT NULL
) ON [PRIMARY]

CREATE TABLE [dbo].[Territorios]
 ([idTerritorio] [nvarchar] (20) NOT NULL ,
 [descripcionTerritorio] [nchar] (50) NOT NULL ,
        [idRegion] [int] NOT NULL
) ON [PRIMARY]

CREATE TABLE [dbo].[TerritoriosEmpleado]
 ([idEmpleado] [int] NOT NULL,
 [idTerritorio] [nvarchar] (20) NOT NULL
) ON [PRIMARY]


ALTER TABLE Region
 ADD CONSTRAINT [PK_Region] PRIMARY KEY  NONCLUSTERED
 (
   [idRegion]
 )  ON [PRIMARY]

ALTER TABLE Territorios
 ADD CONSTRAINT [PK_Territorios] PRIMARY KEY  NONCLUSTERED
 (
   [idTerritorio]
 )  ON [PRIMARY]

ALTER TABLE Territorios
 ADD CONSTRAINT [FK_Territorios_Region] FOREIGN KEY
 (
   [idRegion]
 ) REFERENCES [dbo].[Region] (
   [idRegion]
 )

ALTER TABLE TerritoriosEmpleado
 ADD CONSTRAINT [PK_TerritoriosEmpleado] PRIMARY KEY  NONCLUSTERED
 (
   [idEmpleado],
   [idTerritorio]
 ) ON [PRIMARY]

ALTER TABLE TerritoriosEmpleado
 ADD CONSTRAINT [FK_TerritoriosEmpleado_Empleados] FOREIGN KEY
 (
   [idEmpleado]
 ) REFERENCES [dbo].[Empleados] (
   [idEmpleado]
 )

ALTER TABLE TerritoriosEmpleado
 ADD CONSTRAINT [FK_TerritoriosEmpleado_Territorios] FOREIGN KEY
 (
   [idTerritorio]
 ) REFERENCES [dbo].[Territorios] (
   [idTerritorio]
 )
